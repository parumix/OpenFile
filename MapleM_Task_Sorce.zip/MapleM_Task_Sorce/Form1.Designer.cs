﻿using System;
using System.Globalization;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace MapleStoryM_Task
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.ファイルFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.開くkOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.保存SToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.エルダの初期化ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.日課の初期化ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.週間の初期化ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.エルダの初期化ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.上へToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.下へDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.削除EToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ジュエルToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.赤ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.青ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.緑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.黄色ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.紫ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.遠征隊ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ジャクムToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ホーンテイルToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ピンクビーンToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.シグナスToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column_guild = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Week = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Eluda1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Eluda2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Eluda3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Red = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Blue = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Green = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Yellow = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_Purple = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column_jacm = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column_honetail = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column_pink = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column_signus = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column_comment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.日課の初期化ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripTimerLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルFToolStripMenuItem,
            this.エルダの初期化ToolStripMenuItem,
            this.上へToolStripMenuItem,
            this.下へDToolStripMenuItem,
            this.toolStripMenuItem1,
            this.削除EToolStripMenuItem,
            this.toolStripMenuItem2,
            this.ジュエルToolStripMenuItem,
            this.遠征隊ToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1287, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // ファイルFToolStripMenuItem
            // 
            this.ファイルFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.開くkOToolStripMenuItem,
            this.保存SToolStripMenuItem,
            this.toolStripSeparator1});
            this.ファイルFToolStripMenuItem.Name = "ファイルFToolStripMenuItem";
            this.ファイルFToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.ファイルFToolStripMenuItem.Text = "ファイル(F)";
            // 
            // 開くkOToolStripMenuItem
            // 
            this.開くkOToolStripMenuItem.Name = "開くkOToolStripMenuItem";
            this.開くkOToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.開くkOToolStripMenuItem.Text = "開く(&O)";
            this.開くkOToolStripMenuItem.Click += new System.EventHandler(this.開くkOToolStripMenuItem_Click);
            // 
            // 保存SToolStripMenuItem
            // 
            this.保存SToolStripMenuItem.Name = "保存SToolStripMenuItem";
            this.保存SToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.保存SToolStripMenuItem.Text = "保存(&S)";
            this.保存SToolStripMenuItem.Click += new System.EventHandler(this.保存SToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(109, 6);
            // 
            // エルダの初期化ToolStripMenuItem
            // 
            this.エルダの初期化ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.日課の初期化ToolStripMenuItem1,
            this.週間の初期化ToolStripMenuItem,
            this.エルダの初期化ToolStripMenuItem1});
            this.エルダの初期化ToolStripMenuItem.Name = "エルダの初期化ToolStripMenuItem";
            this.エルダの初期化ToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.エルダの初期化ToolStripMenuItem.Text = "初期化";
            // 
            // 日課の初期化ToolStripMenuItem1
            // 
            this.日課の初期化ToolStripMenuItem1.Name = "日課の初期化ToolStripMenuItem1";
            this.日課の初期化ToolStripMenuItem1.Size = new System.Drawing.Size(148, 22);
            this.日課の初期化ToolStripMenuItem1.Text = "日課の初期化";
            this.日課の初期化ToolStripMenuItem1.Click += new System.EventHandler(this.日課の初期化ToolStripMenuItem1_Click_1);
            // 
            // 週間の初期化ToolStripMenuItem
            // 
            this.週間の初期化ToolStripMenuItem.Name = "週間の初期化ToolStripMenuItem";
            this.週間の初期化ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.週間の初期化ToolStripMenuItem.Text = "週間の初期化";
            this.週間の初期化ToolStripMenuItem.Click += new System.EventHandler(this.週間の初期化ToolStripMenuItem_Click);
            // 
            // エルダの初期化ToolStripMenuItem1
            // 
            this.エルダの初期化ToolStripMenuItem1.Name = "エルダの初期化ToolStripMenuItem1";
            this.エルダの初期化ToolStripMenuItem1.Size = new System.Drawing.Size(148, 22);
            this.エルダの初期化ToolStripMenuItem1.Text = "エルダの初期化";
            this.エルダの初期化ToolStripMenuItem1.Click += new System.EventHandler(this.エルダの初期化ToolStripMenuItem1_Click);
            // 
            // 上へToolStripMenuItem
            // 
            this.上へToolStripMenuItem.Name = "上へToolStripMenuItem";
            this.上へToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.上へToolStripMenuItem.Text = "上へ(&U)";
            this.上へToolStripMenuItem.Click += new System.EventHandler(this.上へToolStripMenuItem_Click);
            // 
            // 下へDToolStripMenuItem
            // 
            this.下へDToolStripMenuItem.Name = "下へDToolStripMenuItem";
            this.下へDToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.下へDToolStripMenuItem.Text = "下へ(&D)";
            this.下へDToolStripMenuItem.Click += new System.EventHandler(this.下へDToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(59, 20);
            this.toolStripMenuItem1.Text = "追加(&A)";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // 削除EToolStripMenuItem
            // 
            this.削除EToolStripMenuItem.Name = "削除EToolStripMenuItem";
            this.削除EToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.削除EToolStripMenuItem.Text = "削除(&E)";
            this.削除EToolStripMenuItem.Click += new System.EventHandler(this.削除EToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(61, 20);
            this.toolStripMenuItem2.Text = "エルダ(&L)";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // ジュエルToolStripMenuItem
            // 
            this.ジュエルToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.赤ToolStripMenuItem,
            this.青ToolStripMenuItem,
            this.緑ToolStripMenuItem,
            this.黄色ToolStripMenuItem,
            this.紫ToolStripMenuItem});
            this.ジュエルToolStripMenuItem.Name = "ジュエルToolStripMenuItem";
            this.ジュエルToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.ジュエルToolStripMenuItem.Text = "ジュエル";
            // 
            // 赤ToolStripMenuItem
            // 
            this.赤ToolStripMenuItem.Name = "赤ToolStripMenuItem";
            this.赤ToolStripMenuItem.Size = new System.Drawing.Size(86, 22);
            this.赤ToolStripMenuItem.Text = "赤";
            this.赤ToolStripMenuItem.Click += new System.EventHandler(this.赤ToolStripMenuItem_Click);
            // 
            // 青ToolStripMenuItem
            // 
            this.青ToolStripMenuItem.Name = "青ToolStripMenuItem";
            this.青ToolStripMenuItem.Size = new System.Drawing.Size(86, 22);
            this.青ToolStripMenuItem.Text = "青";
            this.青ToolStripMenuItem.Click += new System.EventHandler(this.青ToolStripMenuItem_Click);
            // 
            // 緑ToolStripMenuItem
            // 
            this.緑ToolStripMenuItem.Name = "緑ToolStripMenuItem";
            this.緑ToolStripMenuItem.Size = new System.Drawing.Size(86, 22);
            this.緑ToolStripMenuItem.Text = "緑";
            this.緑ToolStripMenuItem.Click += new System.EventHandler(this.緑ToolStripMenuItem_Click);
            // 
            // 黄色ToolStripMenuItem
            // 
            this.黄色ToolStripMenuItem.Name = "黄色ToolStripMenuItem";
            this.黄色ToolStripMenuItem.Size = new System.Drawing.Size(86, 22);
            this.黄色ToolStripMenuItem.Text = "黄";
            this.黄色ToolStripMenuItem.Click += new System.EventHandler(this.黄色ToolStripMenuItem_Click);
            // 
            // 紫ToolStripMenuItem
            // 
            this.紫ToolStripMenuItem.Name = "紫ToolStripMenuItem";
            this.紫ToolStripMenuItem.Size = new System.Drawing.Size(86, 22);
            this.紫ToolStripMenuItem.Text = "紫";
            this.紫ToolStripMenuItem.Click += new System.EventHandler(this.紫ToolStripMenuItem_Click);
            // 
            // 遠征隊ToolStripMenuItem
            // 
            this.遠征隊ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ジャクムToolStripMenuItem,
            this.ホーンテイルToolStripMenuItem,
            this.ピンクビーンToolStripMenuItem,
            this.シグナスToolStripMenuItem});
            this.遠征隊ToolStripMenuItem.Name = "遠征隊ToolStripMenuItem";
            this.遠征隊ToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.遠征隊ToolStripMenuItem.Text = "遠征隊";
            // 
            // ジャクムToolStripMenuItem
            // 
            this.ジャクムToolStripMenuItem.Name = "ジャクムToolStripMenuItem";
            this.ジャクムToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.ジャクムToolStripMenuItem.Text = "ジャクム";
            this.ジャクムToolStripMenuItem.Click += new System.EventHandler(this.ジャクムToolStripMenuItem_Click);
            // 
            // ホーンテイルToolStripMenuItem
            // 
            this.ホーンテイルToolStripMenuItem.Name = "ホーンテイルToolStripMenuItem";
            this.ホーンテイルToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.ホーンテイルToolStripMenuItem.Text = "ホーンテイル";
            this.ホーンテイルToolStripMenuItem.Click += new System.EventHandler(this.ホーンテイルToolStripMenuItem_Click);
            // 
            // ピンクビーンToolStripMenuItem
            // 
            this.ピンクビーンToolStripMenuItem.Name = "ピンクビーンToolStripMenuItem";
            this.ピンクビーンToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.ピンクビーンToolStripMenuItem.Text = "ピンクビーン";
            this.ピンクビーンToolStripMenuItem.Click += new System.EventHandler(this.ピンクビーンToolStripMenuItem_Click);
            // 
            // シグナスToolStripMenuItem
            // 
            this.シグナスToolStripMenuItem.Name = "シグナスToolStripMenuItem";
            this.シグナスToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.シグナスToolStripMenuItem.Text = "シグナス";
            this.シグナスToolStripMenuItem.Click += new System.EventHandler(this.シグナスToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeight = 32;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column_id,
            this.Column_name,
            this.Column_guild,
            this.Column_Week,
            this.Column_Eluda1,
            this.Column_Eluda2,
            this.Column_Eluda3,
            this.Column_Red,
            this.Column_Blue,
            this.Column_Green,
            this.Column_Yellow,
            this.Column_Purple,
            this.Column_jacm,
            this.Column_honetail,
            this.Column_pink,
            this.Column_signus,
            this.Column_comment});
            this.dataGridView1.Location = new System.Drawing.Point(0, 24);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 26;
            this.dataGridView1.Size = new System.Drawing.Size(1287, 149);
            this.dataGridView1.TabIndex = 1;
            // 
            // Column_id
            // 
            this.Column_id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Column_id.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column_id.FillWeight = 30F;
            this.Column_id.Frozen = true;
            this.Column_id.HeaderText = "ID";
            this.Column_id.MaxInputLength = 4;
            this.Column_id.MinimumWidth = 30;
            this.Column_id.Name = "Column_id";
            this.Column_id.ReadOnly = true;
            this.Column_id.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column_id.Width = 30;
            // 
            // Column_name
            // 
            this.Column_name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Column_name.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column_name.FillWeight = 120F;
            this.Column_name.Frozen = true;
            this.Column_name.HeaderText = "キャラクター";
            this.Column_name.MaxInputLength = 16;
            this.Column_name.MinimumWidth = 120;
            this.Column_name.Name = "Column_name";
            this.Column_name.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column_name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column_name.Width = 123;
            // 
            // Column_guild
            // 
            this.Column_guild.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column_guild.FillWeight = 50F;
            this.Column_guild.HeaderText = "日";
            this.Column_guild.MinimumWidth = 50;
            this.Column_guild.Name = "Column_guild";
            this.Column_guild.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column_guild.Width = 50;
            // 
            // Column_Week
            // 
            this.Column_Week.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column_Week.FillWeight = 50F;
            this.Column_Week.HeaderText = "週";
            this.Column_Week.MinimumWidth = 50;
            this.Column_Week.Name = "Column_Week";
            this.Column_Week.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column_Week.Width = 50;
            // 
            // Column_Eluda1
            // 
            this.Column_Eluda1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column_Eluda1.FillWeight = 40F;
            this.Column_Eluda1.HeaderText = "エルダ";
            this.Column_Eluda1.MinimumWidth = 40;
            this.Column_Eluda1.Name = "Column_Eluda1";
            this.Column_Eluda1.Width = 71;
            // 
            // Column_Eluda2
            // 
            this.Column_Eluda2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column_Eluda2.FillWeight = 40F;
            this.Column_Eluda2.HeaderText = "エルダ";
            this.Column_Eluda2.MinimumWidth = 40;
            this.Column_Eluda2.Name = "Column_Eluda2";
            this.Column_Eluda2.Width = 71;
            // 
            // Column_Eluda3
            // 
            this.Column_Eluda3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column_Eluda3.FillWeight = 40F;
            this.Column_Eluda3.HeaderText = "エルダ";
            this.Column_Eluda3.MinimumWidth = 40;
            this.Column_Eluda3.Name = "Column_Eluda3";
            this.Column_Eluda3.Width = 71;
            // 
            // Column_Red
            // 
            this.Column_Red.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle5.NullValue = false;
            this.Column_Red.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column_Red.FillWeight = 25F;
            this.Column_Red.HeaderText = "赤";
            this.Column_Red.MinimumWidth = 25;
            this.Column_Red.Name = "Column_Red";
            this.Column_Red.Width = 40;
            // 
            // Column_Blue
            // 
            this.Column_Blue.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column_Blue.FillWeight = 25F;
            this.Column_Blue.HeaderText = "青";
            this.Column_Blue.MinimumWidth = 25;
            this.Column_Blue.Name = "Column_Blue";
            this.Column_Blue.Width = 40;
            // 
            // Column_Green
            // 
            this.Column_Green.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column_Green.FillWeight = 25F;
            this.Column_Green.HeaderText = "緑";
            this.Column_Green.MinimumWidth = 25;
            this.Column_Green.Name = "Column_Green";
            this.Column_Green.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column_Green.Width = 40;
            // 
            // Column_Yellow
            // 
            this.Column_Yellow.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column_Yellow.FillWeight = 25F;
            this.Column_Yellow.HeaderText = "黄";
            this.Column_Yellow.MinimumWidth = 25;
            this.Column_Yellow.Name = "Column_Yellow";
            this.Column_Yellow.Width = 40;
            // 
            // Column_Purple
            // 
            this.Column_Purple.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column_Purple.FalseValue = "";
            this.Column_Purple.FillWeight = 25F;
            this.Column_Purple.HeaderText = "紫";
            this.Column_Purple.IndeterminateValue = "";
            this.Column_Purple.MinimumWidth = 25;
            this.Column_Purple.Name = "Column_Purple";
            this.Column_Purple.TrueValue = "";
            this.Column_Purple.Width = 40;
            // 
            // Column_jacm
            // 
            this.Column_jacm.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Column_jacm.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column_jacm.FillWeight = 150F;
            this.Column_jacm.HeaderText = "ジャクム";
            this.Column_jacm.Items.AddRange(new object[] {
            "",
            "兜",
            "ベルト",
            "バッジ"});
            this.Column_jacm.MinimumWidth = 100;
            this.Column_jacm.Name = "Column_jacm";
            this.Column_jacm.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Column_honetail
            // 
            this.Column_honetail.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("MS UI Gothic", 18F);
            this.Column_honetail.DefaultCellStyle = dataGridViewCellStyle7;
            this.Column_honetail.FillWeight = 150F;
            this.Column_honetail.HeaderText = "ホーンテイル";
            this.Column_honetail.Items.AddRange(new object[] {
            "",
            "ノーマル",
            "ハード",
            "カオス",
            "ハードネックレス",
            "ハードリング",
            "ハードイヤリング"});
            this.Column_honetail.MinimumWidth = 100;
            this.Column_honetail.Name = "Column_honetail";
            this.Column_honetail.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Column_pink
            // 
            this.Column_pink.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Column_pink.DefaultCellStyle = dataGridViewCellStyle8;
            this.Column_pink.FillWeight = 150F;
            this.Column_pink.HeaderText = "ピンクビーン";
            this.Column_pink.Items.AddRange(new object[] {
            "",
            "ノーマル",
            "ハード",
            "カオス"});
            this.Column_pink.MinimumWidth = 100;
            this.Column_pink.Name = "Column_pink";
            // 
            // Column_signus
            // 
            this.Column_signus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Column_signus.DefaultCellStyle = dataGridViewCellStyle9;
            this.Column_signus.FillWeight = 150F;
            this.Column_signus.HeaderText = "シグナス";
            this.Column_signus.Items.AddRange(new object[] {
            "",
            "ノーマル",
            "ハード",
            "カオス",
            "ユニークコヒヌール",
            "レジェンドコヒヌール",
            "レジェンドシンボル"});
            this.Column_signus.MinimumWidth = 100;
            this.Column_signus.Name = "Column_signus";
            // 
            // Column_comment
            // 
            this.Column_comment.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Column_comment.DefaultCellStyle = dataGridViewCellStyle10;
            this.Column_comment.FillWeight = 300F;
            this.Column_comment.HeaderText = "備考";
            this.Column_comment.MaxInputLength = 255;
            this.Column_comment.MinimumWidth = 150;
            this.Column_comment.Name = "Column_comment";
            this.Column_comment.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // 日課の初期化ToolStripMenuItem
            // 
            this.日課の初期化ToolStripMenuItem.Name = "日課の初期化ToolStripMenuItem";
            this.日課の初期化ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.日課の初期化ToolStripMenuItem.Text = "日課の初期化";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTimerLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 173);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1287, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripTimerLabel
            // 
            this.toolStripTimerLabel.Name = "toolStripTimerLabel";
            this.toolStripTimerLabel.Size = new System.Drawing.Size(110, 17);
            this.toolStripTimerLabel.Text = "2023/09/21 23:32:49";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1287, 195);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.MaximumSize = new System.Drawing.Size(1920, 1440);
            this.MinimumSize = new System.Drawing.Size(375, 150);
            this.Name = "Form1";
            this.Text = "メイプルM タスク ver1.00";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem ファイルFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 開くkOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 保存SToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem 上へToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 下へDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 削除EToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem エルダの初期化ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 日課の初期化ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 日課の初期化ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 週間の初期化ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem エルダの初期化ToolStripMenuItem1;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripTimerLabel;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ToolStripMenuItem ジュエルToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 赤ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 青ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 緑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 黄色ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 紫ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 遠征隊ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ジャクムToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ホーンテイルToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ピンクビーンToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem シグナスToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_name;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_guild;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Week;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Eluda1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Eluda2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Eluda3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Red;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Blue;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Green;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Yellow;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column_Purple;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column_jacm;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column_honetail;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column_pink;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column_signus;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_comment;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
    }
}